import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import {LoginComponent} from './login/login.component';
import {HomescreenComponent} from './homescreen/homescreen.component';
import {LoanComponent} from './loan/loan.component';
import {UpdateDetailsComponent} from './update-details/update-details.component';
import {ViewLoanComponent} from './view-loan/view-loan.component';
const routes: Routes = [
  { path: 'update-details.component', component:UpdateDetailsComponent},
  { path: 'loan.component', component:LoanComponent},
  { path: 'homescreen.component', component:HomescreenComponent},
  { path: '', component:LoginComponent},
  { path: 'register-customer.component', component: RegisterCustomerComponent },
  { path: 'view-loan.component', component: ViewLoanComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
