import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  constructor(private service:SharedService,
    private router: Router) { }

  LoanType:string;
  LoanAmount:string;
  FatherOccupation:string;
  FatherTotalExperience:string;
  FatherExperiencewithCurrentcompany:string;
  CourseFee:string;
  Course:string;
  FatherName:string;
  RationCardNumber:string;
  AnnualIncome:string;
  LoanApplyDate:string;
  ROI:string;
  duration:string;
  customer:string;
  AnnualIncome_l2:string;
  CompanyName:string;
  Designation:string;
  TotalExperience:string;
  ExperiencewithCurrentcompany:string;
  ngOnInit(): void {
  }
  addEducationLoan()
  {
  var val={
    
    LoanType:this.LoanType,
    LoanAmount:this.LoanAmount,
    LoanApplyDate:this.LoanApplyDate,
    LoanIssueDate:this.LoanApplyDate,
    ROI:12,
    duration:this.duration,
    CourseFee:this.CourseFee,
    Course:this.Course,
    FatherName:this.FatherName,
    FatherTotalExperience:this.FatherTotalExperience,
    FatherExperiencewithCurrentcompany:this.FatherExperiencewithCurrentcompany,
    RationCardNumber:this.RationCardNumber,
    AnnualIncome:this.AnnualIncome,
    customer:sessionStorage.getItem("CustomerId"),
    };
    this.service.addLoan(val).subscribe(_=>{alert("Loan Applied Successfully");
    });
  this.router.navigate(['/homescreen.component']);
  }
  addPersonalLoan()
  {
    var val={
      
      LoanType:this.LoanType,
      LoanAmount:this.LoanAmount,
      LoanApplyDate:this.LoanApplyDate,
      LoanIssueDate:this.LoanApplyDate,
      ROI:8,
      duration:this.duration,
      AnnualIncome_l2:this.AnnualIncome_l2,
      CompanyName:this.CompanyName,
      Designation:this.Designation,
      TotalExperience:this.TotalExperience,
      ExperiencewithCurrentcompany:this.ExperiencewithCurrentcompany,
      customer:sessionStorage.getItem("CustomerId")
    };
    this.service.addLoan(val).subscribe(_=>{alert("Loan Applied Successfully");
    });
  this.router.navigate(['/homescreen.component']);
  }
}
