import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-loan',
  templateUrl: './view-loan.component.html',
  styleUrls: ['./view-loan.component.css']
})
export class ViewLoanComponent implements OnInit {

  constructor(private service:SharedService,
    private router: Router) { }

    Customerid:string;
    data:any;
  ngOnInit(): void {
    this.Customerid=sessionStorage.getItem("CustomerId");
    this.service.getLoan(this.Customerid).subscribe(data=>{this.data=data});
  
  }

}
