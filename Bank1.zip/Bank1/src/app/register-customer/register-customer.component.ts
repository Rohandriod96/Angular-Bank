import { Component, Input, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.css']
})
export class RegisterCustomerComponent implements OnInit {

  constructor(private service:SharedService,
    private router: Router) { }

  
  id:string;
  Name:string;
  Username:string;
  Password:string;
  Guardian_Type:string;
  Guardian_Name:string;
  Address:string;
  Citizenship:string;
  State:string;
  Country:string;
  Email_Address:string;
  Gender:string;
  Marital_Status:string;
  Contact_Number:string;
  DateofBirth:string;
  RegistrationDate:string;
  Account_Type:string;
  Branch_Name:string;
  Citizen_Status:string;
  Identification_Document_Number:string;
  ReferenceAccountHolderName:string;
  ReferenceAccountHolderNumber:string;
  ReferenceAccountHolderAddress:string;
  InitialDepositAmount:number;
  ngOnInit(): void {  

  }
  addCustomer()
  {    
    var score1:number = Math.floor(Math.random()*(999-100+1)+100);    
    var score2:number = Math.floor(Math.random()*(999-100+1)+100);    
    var first:string = "R-";
    this.id = first+score1 +'.'+ score2 ;
    if(this.Account_Type=="Saving")
    {
      this.InitialDepositAmount=5000;
    }
    else
    {
      this.InitialDepositAmount=0;
    }
     var currentYear=new Date().getFullYear();
     var substring = this.DateofBirth.substring(0,4);
     var age=currentYear-parseInt(substring);
     
     if(age>96)
     {
       alert("Not applicable");
     }
     if(age<18)
     {
       this.Citizen_Status="Minor"
     }
     if(age>18 && age<=60)
     {
       this.Citizen_Status="Normal"
     }
     if(age>60)
     {
       this.Citizen_Status="Senior"
     }
    var val={
            "id":this.id,
            Name:this.Name,
            Username:this.Username,
            Password:this.Password,
            Guardian_Type:this.Guardian_Type,
            Guardian_Name:this.Guardian_Name,
            Address:this.Address,
            Citizenship:this.Citizenship,
            State:this.State,
            Country:this.Country,
            Email_Address:this.Email_Address,
            Gender:this.Gender,
            Marital_Status:this.Marital_Status,
            Contact_Number:this.Contact_Number,
            DateofBirth:this.DateofBirth,
            RegistrationDate:this.RegistrationDate,
            Account_Type:this.Account_Type,
            Branch_Name:this.Branch_Name,
            Citizen_Status:this.Citizen_Status,
            Identification_Document_Number:this.Identification_Document_Number,
            ReferenceAccountHolderName:this.ReferenceAccountHolderName,
            ReferenceAccountHolderNumber:this.ReferenceAccountHolderNumber,
            ReferenceAccountHolderAddress:this.ReferenceAccountHolderAddress,
            InitialDepositAmount:this.InitialDepositAmount,
          };
     this.service.addCustomer(val).subscribe(_=>{alert("Registered Successfully. Kindly note down your CustomerId is "+this.id);
    });
     this.router.navigate(['']);      
  
    }
    Saving()
    {
      this.Account_Type="Saving";
      this.InitialDepositAmount=5000;
    }
    Salary()
    {
      this.Account_Type="Salary";
      this.InitialDepositAmount=0;
    }
    
}
