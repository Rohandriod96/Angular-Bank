import { ComponentFixture, TestBed } from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { LoanComponent } from './loan.component';
import {SharedService} from 'src/app/shared.service';
import {FormsModule} from '@angular/forms';
describe('LoanComponent', () => {
  let component: LoanComponent;
  let fixture: ComponentFixture<LoanComponent>;
  let sharedService:SharedService
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanComponent ],
      imports:[RouterTestingModule,FormsModule],
      providers:[{provide:SharedService,useValue:sharedService}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
   // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('AddEducationLoan', () => {
    component.addEducationLoan();
  });

  it('AddPersonalLoan', () => {
    component.addPersonalLoan();
  });
});
