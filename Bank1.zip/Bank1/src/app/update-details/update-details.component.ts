import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  constructor(private service:SharedService,
    private router: Router) { }
  Customerid:string;
  id:string;
  Name:string;
  Username:string;
  Password:string;
  Guardian_Type:string;
  Guardian_Name:string;
  Address:string;
  Citizenship:string;
  State:string;
  Country:string;
  Email_Address:string;
  Gender:string;
  Marital_Status:string;
  Contact_Number:string;
  Branch_Name:string;
  Citizen_Status:string;
  Identification_Document_Number:string;
  ReferenceAccountHolderName:string;
  ReferenceAccountHolderNumber:string;
  ReferenceAccountHolderAddress:string;
  

  name:string;
  username:string;
  password:string;
  guardian_Type:string;
  guardian_Name:string;
  address:string;
  citizenship:string;
  state:string;
  country:string;
  email_Address:string;
  gender:string;
  marital_Status:string;
  contact_Number:string;
  DateofBirth:string;
  RegistrationDate:string;
  branch_Name:string;
  citizen_Status:string;
  identification_Document_Number:string;
  referenceAccountHolderName:string;
  referenceAccountHolderNumber:string;
  referenceAccountHolderAddress:string;


  ngOnInit(): void {
    this.Customerid=sessionStorage.getItem("CustomerId");
    this.service.getPassword(this.Customerid).subscribe(data=>{
      var data1:Object=<Object> <any> data;
      this.name= data1["Name"];
      this.username= data1["Username"];
      this.password= data1["Password"];
      this.guardian_Type= data1["Guardian_Type"];
      this.guardian_Name= data1["Guardian_Name"];
      this.address= data1["Address"];
      this.citizenship= data1["Citizenship"];
      this.state= data1["State"];
      this.country= data1["Country"];
      this.email_Address= data1["Email_Address"];
      this.gender=data1["Gender"];
      this.marital_Status=data1["Marital_Status"];
      this.contact_Number=data1["Contact_Number"];
      this.branch_Name=data1["Branch_Name"];
      this.DateofBirth=data1["DateofBirth"];
      this.RegistrationDate=data1["RegistrationDate"];
      this.citizen_Status=data1["Citizen_Status"];
      this.identification_Document_Number=data1["Identification_Document_Number"];
      this.referenceAccountHolderName=data1["ReferenceAccountHolderName"];
      this.referenceAccountHolderNumber=data1["ReferenceAccountHolderNumber"];
      this.referenceAccountHolderAddress=data1["ReferenceAccountHolderAddress"];
  });
  }
  
  updateCustomer()
  {
  var val={
    "id":this.id,
    Name:this.Name,
    Username:this.Username,
    Password:this.Password,
    Guardian_Type:this.Guardian_Type,
    Guardian_Name:this.Guardian_Name,
    Address:this.Address,
    Citizenship:this.Citizenship,
    State:this.State,
    Country:this.Country,
    Email_Address:this.Email_Address,
    Gender:this.Gender,
    Marital_Status:this.Marital_Status,
    Contact_Number:this.Contact_Number,
    DateofBirth:this.DateofBirth,
    RegistrationDate:this.RegistrationDate,
    Branch_Name:this.Branch_Name,
    Citizen_Status:this.Citizen_Status,
    Identification_Document_Number:this.Identification_Document_Number,
    ReferenceAccountHolderName:this.ReferenceAccountHolderName,
    ReferenceAccountHolderNumber:this.ReferenceAccountHolderNumber,
    ReferenceAccountHolderAddress:this.ReferenceAccountHolderAddress,
  };
  
  this.service.updateCustomer(val,this.Customerid).subscribe(_=>{alert("Update Successfully");
  });
  this.router.navigate(['/homescreen.component']);
  }
}
