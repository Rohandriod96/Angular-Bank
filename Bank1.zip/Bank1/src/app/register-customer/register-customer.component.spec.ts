import { ComponentFixture, TestBed } from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { RegisterCustomerComponent } from './register-customer.component';
import {SharedService} from 'src/app/shared.service';
import {FormsModule} from '@angular/forms';

describe('RegisterCustomerComponent', () => {
  let component: RegisterCustomerComponent;
  let fixture: ComponentFixture<RegisterCustomerComponent>;
  let sharedService:SharedService
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterCustomerComponent ],
      imports:[RouterTestingModule,FormsModule],
      providers:[{provide:SharedService,useValue:sharedService}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterCustomerComponent);
    component = fixture.componentInstance;
    sharedService=TestBed.inject(SharedService);
    component.ngOnInit();
 //   fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Saving', () => {
    component.Saving();
  });

  it('Salary', () => {
    component.Salary();
  });

  it('AddCustomer', () => {
    component.addCustomer();
  });
});
