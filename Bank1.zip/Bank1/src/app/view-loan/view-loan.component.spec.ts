import { ComponentFixture, TestBed } from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { ViewLoanComponent } from './view-loan.component';
import {SharedService} from 'src/app/shared.service';
describe('ViewLoanComponent', () => {
  let component: ViewLoanComponent;
  let fixture: ComponentFixture<ViewLoanComponent>;
  let sharedService:SharedService
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewLoanComponent ],
      imports:[RouterTestingModule],
      providers:[{provide:SharedService,useValue:sharedService}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLoanComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
   // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
