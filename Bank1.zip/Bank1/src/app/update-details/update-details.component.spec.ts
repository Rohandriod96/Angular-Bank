import { ComponentFixture, TestBed } from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { UpdateDetailsComponent } from './update-details.component';
import {SharedService} from 'src/app/shared.service';
import {FormsModule} from '@angular/forms';

describe('UpdateDetailsComponent', () => {
  let component: UpdateDetailsComponent;
  let fixture: ComponentFixture<UpdateDetailsComponent>;
  let sharedService:SharedService
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateDetailsComponent ],
      imports:[RouterTestingModule,FormsModule],
      providers:[{provide:SharedService,useValue:sharedService}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDetailsComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    //fixture.detectChanges();
  });

  it('should create', () => {
    component.updateCustomer();
  });

});
