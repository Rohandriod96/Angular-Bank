import { Component, Input,OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';
import { Router } from '@angular/router';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:SharedService,
    private router: Router) { }

  @Input() login:any;
  Customerid:string;
  CustomerData:any;
  Pass:string;
  
  
  ngOnInit(): void {

  }
  
  HomePage()
  {
    sessionStorage.setItem("CustomerId",this.Customerid);
    this.service.getPassword(this.Customerid).subscribe(data=>{
    var data1:Object=<Object> <any> data;
    var pass= data1["Password"];

    if(pass==this.Pass)
    {
      this.router.navigate(['/homescreen.component']);
    }
    else
    {
      alert("Check Customer Id and Password");
    }
    });
    
    
  }
}
