import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from "rxjs";
@Injectable({
  providedIn: 'root'
})
export class SharedService {
readonly APIUrl="http://localhost:3000";
  constructor(private http:HttpClient) { }
  addCustomer(val:any){
    return this.http.post(this.APIUrl + "/Customer",val);
  }
  getPassword(s:string):Observable<any[]>{
    return this.http.get<any>(this.APIUrl+"/Customer/" +s);
  }

  getLoan(s:string):Observable<any[]>{
    return this.http.get<any>(this.APIUrl+"/Loan?customer=" +s);
  }
  
  updateCustomer(val:any,s:string){
    return this.http.patch(this.APIUrl +"/Customer/" +s,val);
  }
  addLoan(val:any){
    return this.http.post(this.APIUrl + "/Loan",val);
  }
}
