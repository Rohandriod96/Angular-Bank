import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {SharedService} from './shared.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import { LoginComponent } from './login/login.component';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { HomescreenComponent } from './homescreen/homescreen.component';
import { LoanComponent } from './loan/loan.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { ViewLoanComponent } from './view-loan/view-loan.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterCustomerComponent,
    LoginComponent,
    HomescreenComponent,
    LoanComponent,
    UpdateDetailsComponent,
    ViewLoanComponent
  ],
  imports: [
    MatFormFieldModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
